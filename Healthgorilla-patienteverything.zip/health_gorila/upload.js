

const uploadFileData = async(data) => {
    const results = [];
    const response = [];
    const chunkSize = 5;

}